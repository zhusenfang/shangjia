package com.project.view;


import com.project.bean.GroupMemberBean;

/**
 * Created by sshss on 2017/12/8.
 */

public interface IGroupMemberView extends IView {
    void showMembers(GroupMemberBean bean);

}
