package com.project.bean;

/**
 * Created by sshss on 2018/1/22.
 */

public class BusShareLocBean {
    public double latitude;
    public double longitude;
    public String address;

    public BusShareLocBean(double latitude, double longitude, String address) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.address = address;
    }
}
