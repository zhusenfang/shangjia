package com.project.adapter;

import android.view.View;

/**
 * Created by sshss on 2017/6/28.
 */

public abstract class BaseViewHolder {
    public BaseViewHolder(View convertView) {
    }
}
