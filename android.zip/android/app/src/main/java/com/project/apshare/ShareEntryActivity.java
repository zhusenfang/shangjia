package com.project.apshare;

import com.umeng.socialize.media.ShareCallbackActivity;

public class ShareEntryActivity extends ShareCallbackActivity {

}
