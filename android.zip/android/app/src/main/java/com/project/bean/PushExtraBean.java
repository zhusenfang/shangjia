package com.project.bean;

/**
 * Created by sshss on 2018/1/9.
 */

public class PushExtraBean {


    public String orderId;
    public int orderType;
    public int type;
}
