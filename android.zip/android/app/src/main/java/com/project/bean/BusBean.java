package com.project.bean;

/**
 * Created by sshss on 2017/9/1.
 */

public class BusBean {
    public int action ;

    public BusBean(int action) {
        this.action = action;
    }
}
