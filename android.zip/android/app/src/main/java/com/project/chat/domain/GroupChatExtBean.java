package com.project.chat.domain;

/**
 * Created by sshss on 2017/9/19.
 */

public class GroupChatExtBean {
    public String orderId;
    public int groupType;
    public int orderType;
    public String desc;

    public String inviterNick;
    public String inviterHead;
}
