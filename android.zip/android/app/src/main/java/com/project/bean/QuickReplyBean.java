package com.project.bean;

import java.util.List;

/**
 * Created by sshss on 2017/12/27.
 */

public class QuickReplyBean extends BaseBean {

    public List<Data> data;

    public static class Data {

        public String message;
    }
}
